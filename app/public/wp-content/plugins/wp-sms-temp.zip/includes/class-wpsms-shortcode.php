<?php

namespace WP_SMS;

if (!defined('ABSPATH')) {
    exit;
} // Exit if accessed directly

class Shortcode
{
    public function __construct()
    {

    }
}

new Shortcode();