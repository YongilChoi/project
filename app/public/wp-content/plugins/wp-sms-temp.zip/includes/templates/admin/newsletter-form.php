<br>
<div class="notice notice-warning" style="padding: 11px;">
    <form action="https://static.mailerlite.com/webforms/submit/k7h5a2" data-code="k7h5a2" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate>
        <?php _e('Signup for news and special offers from WP SMS!', 'wp-sms'); ?>
        <input type="email" value="<?php bloginfo('admin_email'); ?>" name="fields[email]" class="required email" id="mce-EMAIL">
        <input type="hidden" name="ml-submit" value="1">
        <input type="hidden" name="anticsrf" value="true">
        <input type="submit" value="<?php _e('Subscribe', 'wp-sms'); ?>" name="subscribe" id="mc-embedded-subscribe" class="button">
        <a href="?page=wp-sms-settings&action=wpsms-hide-newsletter" class="button"><?php _e('Close', 'wp-sms'); ?></a>
    </form>
</div>